# Salesforce Language Syntax

https://github.com/cemerson/salesforce-language-syntax

Simple package (files) to add Salesforce Apex and Visualforce language syntax support to Sublime Text. These files were extracted from the legendary MavensMate package since it has been discontinued and may eventually (sadly) stop working.

MavensMate by Joe Ferraro: 
https://github.com/joeferraro/MavensMate

Salesforce Apex Documentation: 
https://developer.salesforce.com/docs/atlas.en-us.apexcode.meta/apexcode/apex_dev_guide.htm





